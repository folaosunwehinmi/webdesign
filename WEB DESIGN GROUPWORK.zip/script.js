function playRPS(playerPick) {
    const picks = ['rock', 'paper', 'scissors'];
    const computerPick = picks[Math.floor(Math.random() * picks.length)];

    let result;

    if (playerPick === computerPick) {
        result = 'It\'s a draw.';
    } else if (
        (playerPick === 'rock' && computerPick === 'scissors') ||
        (playerPick === 'paper' && computerPick === 'rock') ||
        (playerPick === 'scissors' && computerPick === 'paper')
    ) {
        result = `You won! ${playerPick} beats ${computerPick}.`;
    } else {
        result = `You lost. ${computerPick} beats ${playerPick}.`;
    }

    document.getElementById('result').innerHTML = result;
}